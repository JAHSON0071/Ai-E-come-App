function previewImage(src, alt) {
  const modal = document.getElementById("previewModal");
  const modalImg = document.getElementById("previewImage");
  const caption = document.getElementById("caption");

  modal.style.display = "block";
  modalImg.src = src;
  caption.innerText = alt;
}

function closePreview() {
  document.getElementById("previewModal").style.display = "none";
}

const designs = [
  { src: "images/design1.jpg", alt: "Design 1", file: "images/design1.jpg" },
  { src: "images/design2.jpg", alt: "Design 2", file: "images/design2.jpg" },
];

const templates = [
  { src: "images/template1.jpg", alt: "Template 1", file: "templates/template1.pdf" },
  { src: "images/template2.jpg", alt: "Template 2", file: "templates/template2.pdf" },
];

function loadContent() {
  const designSection = document.querySelector("#designs .grid");
  const templateSection = document.querySelector("#templates .grid");

  designs.forEach(({ src, alt, file }) => {
    designSection.innerHTML += `
      <div class="item">
        <img src="${src}" alt="${alt}" onclick="previewImage('${src}', '${alt}')" />
        <button onclick="downloadFile('${file}')">Download</button>
        <div id="paypal-${alt.replace(" ", "").toLowerCase()}"></div>
        <script>createPayPalButton("paypal-${alt.replace(" ", "").toLowerCase()}", "5.00")</script>
      </div>`;
  });

  templates.forEach(({ src, alt, file }) => {
    templateSection.innerHTML += `
      <div class="item">
        <img src="${src}" alt="${alt}" onclick="previewImage('${src}', '${alt}')" />
        <button onclick="downloadFile('${file}')">Download</button>
        <div id="paypal-${alt.replace(" ", "").toLowerCase()}"></div>
        <script>createPayPalButton("paypal-${alt.replace(" ", "").toLowerCase()}", "5.00")</script>
      </div>`;
  });
}

// PayPal integration
function createPayPalButton(containerId, price) {
  paypal.Buttons({
    createOrder: (data, actions) => {
      return actions.order.create({
        purchase_units: [{ amount: { value: price } }],
      });
    },
    onApprove: (data, actions) => {
      return actions.order.capture().then((details) => {
        alert("Transaction completed by " + details.payer.name.given_name);
      });
    },
  }).render(`#${containerId}`);
}

// Load content on page load
window.onload = loadContent;

// Function to download files
function downloadFile(path) {
  const link = document.createElement("a");
  link.href = path;
  link.download = path.split('/').pop(); // Use file name as the download name
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}